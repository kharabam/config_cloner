import json
import os

# Get absolute path to current directory
current_dir = os.path.dirname(os.path.abspath(__file__))
config_path = os.path.join(current_dir, 'config.json')
ip_path = os.path.join(current_dir, 'ip.txt')

try:
    # Step 1: Load original JSON data from config.json
    with open(config_path, 'r') as json_file:
        original_config = json.load(json_file)
except FileNotFoundError:
    print(f"Error: {config_path} not found.")
    exit(1)
except json.JSONDecodeError:
    print("Error: Invalid JSON format in config.json.")
    exit(1)

# Step 2: Read server IP and port from ip.txt
try:
    with open(ip_path, 'r') as ip_file:
        ip_lines = ip_file.readlines()

        if not ip_lines:
            raise ValueError("Error: ip.txt is empty.")

        # Initialize a list to store cloned configurations
        cloned_configs = []

        # Process each line in ip.txt
        for idx, line in enumerate(ip_lines):
            line = line.strip()
            if not line:
                continue

            # Split the line into server_ip and port
            ip_port_parts = line.split(':')

            if len(ip_port_parts) != 2:
                print(f"Warning: Skipping line {idx+1} in ip.txt due to invalid format.")
                continue

            new_ip = ip_port_parts[0].strip()
            new_port = int(ip_port_parts[1].strip())

            # Clone the original configuration
            cloned_config = original_config['outbounds'][0].copy()

            # Modify fields for this specific server
            cloned_config['server'] = new_ip
            cloned_config['server_port'] = new_port
            cloned_config['tag'] = f'warp{idx + 1}'  # Adjust tag naming scheme

            # Append to list of clones
            cloned_configs.append(cloned_config)

except FileNotFoundError:
    print(f"Error: {ip_path} not found.")
    exit(1)
except ValueError as ve:
    print(f"Error: {ve}")
    exit(1)

# Step 3: Update original JSON with cloned configurations
original_config['outbounds'] = cloned_configs

# Step 4: Save modified JSON configurations to file
save_path = os.path.join(current_dir, 'modified_config.json')
with open(save_path, 'w') as json_file:
    json.dump(original_config, json_file, indent=4)

print(f'{len(cloned_configs)} configurations cloned and saved successfully.')
print(f'Saved to: {save_path}')  # Add this line to check where the file is saved
